# PLC Ladder Lab — Android prototype

Versi awal: **0.1.0**. Proyek Android Studio berbasis Kotlin + Jetpack Compose.

## Fitur prototipe
- Ladder satu rung dengan elemen seri.
- Tambah/hapus NO, NC, COIL, TIMER, COUNTER.
- Edit alamat PLC, preset timer/counter, dan komentar.
- Toggle input digital dan jalankan satu scan logika.
- Ekspor data internal ke JSON (bukan format vendor).

## Batasan penting
- Belum membaca/menulis format Omron CX-Programmer `.CXT` atau `.CXP`.
- Belum kompatibel dengan GX Developer.
- Timer belum mengukur waktu nyata dan counter belum mendeteksi tepi pulsa.
- Belum mendukung rung paralel, banyak rung, instruksi vendor, simbol proyek, atau komunikasi PLC.
- Jangan gunakan simulator ini untuk mengendalikan mesin produksi atau sebagai satu-satunya verifikasi keselamatan.

## Build APK
1. Pasang Android Studio versi yang mendukung Android Gradle Plugin 8.7.x.
2. Pastikan Android SDK Platform 35 dan JDK 17 terpasang.
3. Ekstrak ZIP, lalu buka folder `PLC_Ladder_Android` di Android Studio.
4. Tunggu Gradle Sync selesai.
5. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. APK debug biasanya dibuat di `app/build/outputs/apk/debug/app-debug.apk`.

Jika ingin memakai command line dari folder proyek dan Gradle tersedia:
```bash
gradle assembleDebug
```
Perintah tersebut memerlukan Android SDK/JDK yang sesuai. ZIP ini tidak menyertakan Gradle Wrapper.

## Struktur
- `app/src/main/java/com/example/plcladder/MainActivity.kt`: UI, model elemen, dan simulasi dasar.
- `app/src/main/AndroidManifest.xml`: konfigurasi aplikasi.
- `app/build.gradle.kts`: dependensi dan konfigurasi build.


## Build otomatis melalui GitHub Actions (tanpa Android Studio di HP)
1. Di komputer atau browser, buat repository GitHub baru (misalnya `PLC-Ladder-Android`).
2. Unggah seluruh isi folder proyek ini ke repository, termasuk folder `.github/workflows/`.
3. Buka tab **Actions**, pilih workflow **Build Android APK**, lalu tekan **Run workflow** jika belum berjalan otomatis.
4. Tunggu hingga workflow selesai dengan tanda hijau.
5. Buka hasil run dan unduh artifact **PLC-Ladder-Lab-debug-APK**.
6. Ekstrak ZIP artifact untuk mendapatkan `app-debug.apk`, lalu kirim APK ke HP Android dan instal.

Catatan: workflow ini membangun APK debug yang belum ditandatangani untuk distribusi publik. Instalasi mungkin meminta izin untuk memasang aplikasi dari sumber tersebut. Build tetap harus lulus di GitHub Actions; keberhasilan belum dijamin sebelum dijalankan.
