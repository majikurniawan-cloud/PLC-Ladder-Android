package com.example.plcladder

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PLCApp() }
    }
}

enum class ElementType(val title: String) {
    NO("NO"), NC("NC"), COIL("COIL"), TIMER("TIMER"), COUNTER("COUNTER")
}

data class LadderElement(
    val id: Int,
    val type: ElementType,
    val address: String,
    val preset: Int = 5,
    val comment: String = ""
)

data class Rung(val id: Int, val elements: List<LadderElement>)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PLCApp() {
    val elements = remember {
        mutableStateListOf(
            LadderElement(1, ElementType.NO, "X0", comment = "Start"),
            LadderElement(2, ElementType.NC, "X1", comment = "Stop"),
            LadderElement(3, ElementType.COIL, "Y0", comment = "Motor")
        )
    }
    val inputs = remember { mutableStateMapOf<String, Boolean>("X0" to false, "X1" to false) }
    val outputs = remember { mutableStateMapOf<String, Boolean>() }
    var running by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Simulator berhenti") }
    var nextId by remember { mutableIntStateOf(4) }
    var projectName by remember { mutableStateOf("Proyek PLC 1") }
    var showHelp by remember { mutableStateOf(false) }
    var exportedJson by remember { mutableStateOf("") }

    fun simulate() {
        val coil = elements.lastOrNull { it.type == ElementType.COIL }
        var power = true
        for (e in elements) {
            when (e.type) {
                ElementType.NO -> power = power && (inputs[e.address] ?: false)
                ElementType.NC -> power = power && !(inputs[e.address] ?: false)
                ElementType.COIL -> outputs[e.address] = power
                ElementType.TIMER -> {
                    // Prototype semantics: timer done when rung is energized and preset is zero.
                    // Real elapsed-time behavior is intentionally not claimed in this first build.
                    power = power && e.preset <= 0
                }
                ElementType.COUNTER -> {
                    // Prototype semantics: counter is a pass-through placeholder pending edge counting.
                    power = power
                }
            }
        }
        if (coil == null) status = "Tidak ada coil output pada rung."
        else status = "Scan selesai • ${coil.address} = ${if (outputs[coil.address] == true) "ON" else "OFF"}"
        running = true
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF1565C0))) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("PLC Ladder Lab", fontWeight = FontWeight.Bold)
                            Text("Editor & simulator offline • v0.1", fontSize = 11.sp)
                        }
                    },
                    actions = {
                        TextButton(onClick = { showHelp = true }) { Text("Bantuan") }
                    }
                )
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(top = 12.dp, bottom = 28.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = projectName,
                        onValueChange = { projectName = it },
                        label = { Text("Nama proyek") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF3F6FA))) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("LADDER EDITOR", fontWeight = FontWeight.Bold, color = Color(0xFF334155))
                            Text("Rung 000 • logika seri", fontSize = 12.sp, color = Color.Gray)
                            Row(
                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("L", fontWeight = FontWeight.Bold, color = Color.DarkGray)
                                elements.forEach { e ->
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("──", color = Color.DarkGray)
                                        when (e.type) {
                                            ElementType.NO -> Text("─| |─", fontWeight = FontWeight.Bold, color = Color(0xFF1565C0))
                                            ElementType.NC -> Text("─|/|─", fontWeight = FontWeight.Bold, color = Color(0xFF1565C0))
                                            ElementType.COIL -> Text("─( )", fontWeight = FontWeight.Bold, color = Color(0xFF087F23))
                                            ElementType.TIMER -> Text("[TON]", fontWeight = FontWeight.Bold, color = Color(0xFF7B1FA2))
                                            ElementType.COUNTER -> Text("[CTU]", fontWeight = FontWeight.Bold, color = Color(0xFF7B1FA2))
                                        }
                                    }
                                }
                                Text("── R", color = Color.DarkGray)
                            }
                            Text("Visualisasi satu rung seri. Branch paralel dan multi-rung belum didukung.", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }
                item {
                    Text("Elemen rung", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Ubah alamat, preset timer/counter, komentar, atau hapus elemen.", fontSize = 12.sp, color = Color.Gray)
                }
                itemsIndexed(elements, key = { _, e -> e.id }) { index, e ->
                    ElementEditor(
                        element = e,
                        onChange = { changed -> elements[index] = changed },
                        onDelete = { elements.removeAt(index) }
                    )
                }
                item {
                    Text("Tambah elemen", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            AddButton("NO", Modifier.weight(1f)) { elements.add(LadderElement(nextId.also { nextId++ }, ElementType.NO, "X2")) }
                            AddButton("NC", Modifier.weight(1f)) { elements.add(LadderElement(nextId.also { nextId++ }, ElementType.NC, "X3")) }
                            AddButton("COIL", Modifier.weight(1f)) { elements.add(LadderElement(nextId.also { nextId++ }, ElementType.COIL, "Y1")) }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            AddButton("TIMER", Modifier.weight(1f)) { elements.add(LadderElement(nextId.also { nextId++ }, ElementType.TIMER, "T0", 5)) }
                            AddButton("COUNTER", Modifier.weight(1f)) { elements.add(LadderElement(nextId.also { nextId++ }, ElementType.COUNTER, "C0", 3)) }
                        }
                    }
                }
                item {
                    Text("I/O Simulator", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Card(border = BorderStroke(1.dp, Color(0xFFD8DEE8))) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Input digital", fontWeight = FontWeight.SemiBold)
                            val inputAddresses = (inputs.keys + elements.filter { it.type == ElementType.NO || it.type == ElementType.NC }.map { it.address })
                                .distinct().sorted()
                            inputAddresses.forEach { address ->
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                    Text(address, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
                                    Text(if (inputs[address] == true) "ON" else "OFF", color = if (inputs[address] == true) Color(0xFF087F23) else Color.Gray)
                                    Switch(checked = inputs[address] == true, onCheckedChange = { inputs[address] = it })
                                }
                            }
                            Divider()
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                Text("Output", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                Text(outputs.entries.joinToString { "${it.key}: ${if (it.value) "ON" else "OFF"}" }.ifBlank { "Belum discan" })
                            }
                            Button(onClick = { simulate() }, modifier = Modifier.fillMaxWidth()) { Text("Jalankan scan") }
                            OutlinedButton(
                                onClick = {
                                    outputs.clear()
                                    running = false
                                    status = "Simulator di-reset"
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Reset output") }
                            Text(status, color = if (running) Color(0xFF1565C0) else Color.Gray, fontSize = 13.sp)
                        }
                    }
                }
                item {
                    Text("Simpan / ekspor", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Versi awal menyiapkan ekspor JSON untuk prototipe internal. Ini bukan format .CXT/.CXP dan tidak dapat langsung dibuka oleh CX-Programmer.", fontSize = 12.sp, color = Color.Gray)
                    Button(
                        onClick = {
                            val json = JSONObject()
                            json.put("format", "plc-ladder-lab-json-v1")
                            json.put("projectName", projectName)
                            val array = JSONArray()
                            elements.forEach { e ->
                                array.put(JSONObject().put("id", e.id).put("type", e.type.name)
                                    .put("address", e.address).put("preset", e.preset).put("comment", e.comment))
                            }
                            json.put("elements", array)
                            // Display JSON in the app; user can copy it manually in this prototype.
                            status = "JSON siap: ${json.toString().length} karakter. Gunakan tombol Salin JSON di bawah."
                            exportedJson = json.toString(2)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Siapkan JSON") }
                    if (exportedJson.isNotBlank()) {
                        SelectionContainerText(exportedJson)
                        OutlinedButton(onClick = { status = "JSON tampil di atas; salin teks secara manual." }, modifier = Modifier.fillMaxWidth()) {
                            Text("JSON siap ditampilkan")
                        }
                    }
                }
                item {
                    Text("Batasan versi 0.1", fontWeight = FontWeight.Bold)
                    Text(
                        "• Belum mengimpor file CX-Programmer atau GX Developer.\n" +
                        "• Timer belum memakai waktu nyata dan counter belum menghitung tepi pulsa.\n" +
                        "• Logika seri satu rung; belum ada cabang paralel, set/reset, atau banyak rung.\n" +
                        "• Simulator untuk pembelajaran saja, bukan untuk mengendalikan mesin produksi.",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }
            }
        }
    }

    if (showHelp) {
        AlertDialog(
            onDismissRequest = { showHelp = false },
            confirmButton = { TextButton(onClick = { showHelp = false }) { Text("Tutup") } },
            title = { Text("PLC Ladder Lab") },
            text = { Text("Prototipe offline untuk belajar Ladder. NO/NC membaca input digital; coil mengikuti hasil logika seri. Timer dan counter masih berupa placeholder. Belum kompatibel dengan file proyek Omron/Mitsubishi.") }
        )
    }
}

@Composable
fun ElementEditor(element: LadderElement, onChange: (LadderElement) -> Unit, onDelete: () -> Unit) {
    Card(border = BorderStroke(1.dp, Color(0xFFD8DEE8))) {
        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${element.type.title} • ID ${element.id}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = onDelete) { Text("Hapus", color = Color(0xFFB3261E)) }
            }
            OutlinedTextField(
                value = element.address,
                onValueChange = { onChange(element.copy(address = it.trim().uppercase())) },
                label = { Text("Alamat PLC") },
                supportingText = { Text("Contoh: X0, X1, Y0, T0, C0, CIO 0.00") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            if (element.type == ElementType.TIMER || element.type == ElementType.COUNTER) {
                OutlinedTextField(
                    value = element.preset.toString(),
                    onValueChange = { it.toIntOrNull()?.let { value -> onChange(element.copy(preset = value.coerceAtLeast(0))) } },
                    label = { Text("Preset (unit simulasi)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
            OutlinedTextField(
                value = element.comment,
                onValueChange = { onChange(element.copy(comment = it)) },
                label = { Text("Komentar") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
        }
    }
}

@Composable
fun AddButton(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = modifier) { Text("+ $label") }
}

@Composable
fun SelectionContainerText(value: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF6F8FA))) {
        Text(value, modifier = Modifier.fillMaxWidth().padding(10.dp), fontSize = 11.sp)
    }
}
